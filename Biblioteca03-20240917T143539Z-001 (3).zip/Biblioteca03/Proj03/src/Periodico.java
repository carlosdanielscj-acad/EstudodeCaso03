import java.util.Calendar;
import java.util.GregorianCalendar;

public class Periodico extends Livro {
    
    public Periodico(String titulo) {
        super(titulo);
    }

    @Override
    public boolean empresta(Usuario u) {
        if (u.isProfessor()) {
            GregorianCalendar cal = new GregorianCalendar();
            this.retiradoPor = u;
            this.dtEmprestimo = cal.getTime();
            cal.add(Calendar.DATE, 7); // Prazo de 7 dias para periódicos
            this.dtDevolucao = cal.getTime();
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Periódico: " + super.toString();
    }
}
