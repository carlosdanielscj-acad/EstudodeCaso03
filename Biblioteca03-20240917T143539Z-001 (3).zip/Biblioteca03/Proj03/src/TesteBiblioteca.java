import java.util.ArrayList;
import java.util.Scanner;

public class TesteBiblioteca {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ControleBiblioteca controleBiblioteca = new ControleBiblioteca();

        int opcao;
        do {
            System.out.println("\nBem-vindo ao Sistema da Biblioteca!");
            System.out.println("1. Entrar como Usuário");
            System.out.println("2. Entrar como Desenvolvedor");
            System.out.println("3. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Consumir a nova linha

            switch (opcao) {
                case 1:
                    entrarComoUsuario(controleBiblioteca, scanner);
                    break;
                case 2:
                    entrarComoDesenvolvedor(controleBiblioteca, scanner);
                    break;
                case 3:
                    System.out.println("Saindo do sistema...");
                    break;
                default:
                    System.out.println("Opção inválida, tente novamente.");
            }
        } while (opcao != 3);

        scanner.close();
    }

    // Função para manipular entrada como usuário (Aluno ou Professor)
    public static void entrarComoUsuario(ControleBiblioteca controleBiblioteca, Scanner scanner) {
        System.out.println("\nEntrar como:");
        System.out.println("1. Aluno");
        System.out.println("2. Professor");
        System.out.print("Escolha uma opção: ");
        int tipoUsuario = scanner.nextInt();
        scanner.nextLine(); // Consumir nova linha

        Usuario usuario;
        if (tipoUsuario == 1) {
            usuario = criarUsuarioAluno(scanner);
        } else if (tipoUsuario == 2) {
            usuario = criarUsuarioProfessor(scanner);
        } else {
            System.out.println("Tipo de usuário inválido!");
            return;
        }

        controleBiblioteca.adicionarUsuario(usuario);
        realizarOperacoesUsuario(usuario, controleBiblioteca, scanner);
    }

    // Função para manipular entrada como desenvolvedor
    public static void entrarComoDesenvolvedor(ControleBiblioteca controleBiblioteca, Scanner scanner) {
        System.out.println("\nOpções de Desenvolvedor:");
        System.out.println("1. Cadastrar Livro");
        System.out.println("2. Listar Livros Disponíveis");
        System.out.print("Escolha uma opção: ");
        int opcao = scanner.nextInt();
        scanner.nextLine(); // Consumir nova linha

        switch (opcao) {
            case 1:
                Livro livro = criarLivro(scanner);
                controleBiblioteca.adicionarItem(livro);
                System.out.println("Livro cadastrado com sucesso!");
                break;
            case 2:
                for (Item item : controleBiblioteca.listarItensDisponiveis()) {
                    System.out.println(item);
                }
                break;
            default:
                System.out.println("Opção inválida!");
        }
    }

    // Função para criar um aluno
    public static UsuarioAluno criarUsuarioAluno(Scanner scanner) {
        System.out.print("Digite o nome do Aluno: ");
        String nome = scanner.nextLine();
        System.out.print("Digite a data limite (em formato YYYY-MM-DD) para renovação: ");
        String dataLimite = scanner.nextLine();
        return new UsuarioAluno(nome,  2004 / 01 / 01);
    }

    // Função para criar um professor
    public static UsuarioProfessor criarUsuarioProfessor(Scanner scanner) {
        System.out.print("Digite o nome do Professor: ");
        String nome = scanner.nextLine();
        return new UsuarioProfessor(nome);
    }

    // Função para criar um livro
    public static Livro criarLivro(Scanner scanner) {
        System.out.print("Digite o título do livro: ");
        String titulo = scanner.nextLine();
        return new Livro(titulo);
    }

    // Função para realizar operações com o usuário
    public static void realizarOperacoesUsuario(Usuario usuario, ControleBiblioteca controleBiblioteca,
            Scanner scanner) {
        int opcao;
        do {
            System.out.println("\nOpções de Usuário:");
            System.out.println("1. Emprestar Livro");
            System.out.println("2. Retornar Livro");
            if (usuario instanceof UsuarioProfessor) {
                System.out.println("3. Bloquear Livro");
                System.out.println("4. Desbloquear Livro");
            }
            System.out.println("5. Exibir Status dos Livros");
            System.out.println("6. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Consumir nova linha

            switch (opcao) {
                case 1:
                    emprestarLivro(usuario, controleBiblioteca, scanner);
                    break;
                case 2:
                    retornarLivro(usuario, controleBiblioteca, scanner);
                    break;
                case 3:
                    if (usuario instanceof UsuarioProfessor) {
                        bloquearLivro((UsuarioProfessor) usuario, controleBiblioteca, scanner);
                    } else {
                        System.out.println("Opção inválida para este usuário.");
                    }
                    break;
                case 4:
                    if (usuario instanceof UsuarioProfessor) {
                        desbloquearLivro((UsuarioProfessor) usuario, controleBiblioteca, scanner);
                    } else {
                        System.out.println("Opção inválida para este usuário.");
                    }
                    break;
                case 5:
                    System.out.print("Digite o título do livro que deseja verificar: ");
                    String titulo = scanner.nextLine();
                    System.out.println(controleBiblioteca.exibirStatusItem(titulo));
                    break;
                case 6:
                    System.out.println("Saindo do menu de usuário...");
                    break;
                default:
                    System.out.println("Opção inválida, tente novamente.");
            }
        } while (opcao != 6);
    }

    // Função para emprestar livro
    public static void emprestarLivro(Usuario usuario, ControleBiblioteca controleBiblioteca, Scanner scanner) {
        System.out.print("Digite o título do livro que deseja emprestar: ");
        String titulo = scanner.nextLine();
        Livro livro = controleBiblioteca.buscarLivro(titulo);
        if (livro != null) {
            controleBiblioteca.emprestarItem(usuario, livro);
        } else {
            System.out.println("Livro não encontrado!");
        }
    }

    // Função para retornar livro
    public static void retornarLivro(Usuario usuario, ControleBiblioteca controleBiblioteca, Scanner scanner) {
        System.out.print("Digite o título do livro que deseja retornar: ");
        String titulo = scanner.nextLine();
        Livro livro = controleBiblioteca.buscarLivro(titulo);
        if (livro != null) {
            controleBiblioteca.retornarItem(usuario, livro);
        } else {
            System.out.println("Livro não encontrado!");
        }
    }

    // Função para bloquear livro (apenas professores)
    public static void bloquearLivro(UsuarioProfessor professor, ControleBiblioteca controleBiblioteca,
            Scanner scanner) {
        System.out.print("Digite o título do livro que deseja bloquear: ");
        String titulo = scanner.nextLine();
        Livro livro = controleBiblioteca.buscarLivro(titulo);
        if (livro != null) {
            livro.bloqueia(professor, 7);
            System.out.println("Livro bloqueado com sucesso.");
        } else {
            System.out.println("Livro não encontrado!");
        }
    }

    // Função para desbloquear livro (apenas professores)
    public static void desbloquearLivro(UsuarioProfessor professor, ControleBiblioteca controleBiblioteca,
            Scanner scanner) {
        System.out.print("Digite o título do livro que deseja desbloquear: ");
        String titulo = scanner.nextLine();
        Livro livro = controleBiblioteca.buscarLivro(titulo);
        if (livro != null) {
            livro.desbloqueia(professor);
            System.out.println("Livro desbloqueado com sucesso.");
        } else {
            System.out.println("Livro não encontrado!");
        }
    }
}
