import java.util.Scanner;

public class Terminal {
    private Scanner scanner;
    private BancoDados bancoDados; // Adiciona uma referência para BancoDados

    public Terminal(BancoDados bancoDados) {
        this.scanner = new Scanner(System.in);
        this.bancoDados = bancoDados;
    }

    public int mostrarMenuPrincipal() {
        System.out.println("Controle de Biblioteca:");
        System.out.println("1. Modo Administrador");
        System.out.println("2. Modo Atendimento");
        System.out.println("0. Sair");
        return scanner.nextInt();
    }

    public int mostrarMenuAdministrador() {
        System.out.println("Modo Administrador:");
        System.out.println("1. Cadastrar Livro");
        System.out.println("2. Cadastrar Periódico");
        System.out.println("3. Cadastrar Mapa Temático");
        System.out.println("4. Cadastrar Usuário");
        System.out.println("5. Remover Livro");
        System.out.println("6. Remover Periódico");
        System.out.println("7. Remover Mapa Temático");
        System.out.println("8. Remover Usuário");
        System.out.println("0. Voltar");
        return scanner.nextInt();
    }

    public int mostrarMenuAtendimento(Usuario usuario) {
        System.out.println("Modo Atendimento:");
        System.out.println("1. Retirada de Livro");
        System.out.println("2. Devolução");
        System.out.println("3. Consulta da Situação");
        if (usuario.isProfessor()) {
            System.out.println("4. Bloqueio");
            System.out.println("5. Desbloqueio");
        }
        System.out.println("0. Voltar");
        return scanner.nextInt();
    }

    public String receberTitulo() {
        System.out.println("Digite o título:");
        scanner.nextLine(); 
        return scanner.nextLine();
    }

    public String receberAutor() {
        System.out.println("Digite o autor:");
        return scanner.nextLine();
    }

    public String receberEditora() {
        System.out.println("Digite a editora:");
        return scanner.nextLine();
    }

    public int receberNivelPrivilegio() {
        System.out.println("Digite o nível de privilégio (1 - Usuario externo, 2 - Aluno, 3 - Professor):");
        return scanner.nextInt();
    }

    public int receberNumeroUsuario() {
        System.out.println("Digite o número do usuário:");
        return scanner.nextInt();
    }

    public String receberNome() {
        System.out.println("Digite o nome do usuário:");
        scanner.nextLine(); 
        return scanner.nextLine();
    }

    public String receberTipoUsuario() {
        System.out.println("Digite o tipo de usuário (Aluno/Professor):");
        return scanner.nextLine();
    }

    public int receberPrazoEmprestimo() {
        System.out.println("Digite o prazo de empréstimo (em dias):");
        return scanner.nextInt();
    }

    public Item selecionarItemParaEmprestimo() {
        String titulo = receberTitulo();
        Item item = bancoDados.buscarItem(Livro.class, titulo); // Use bancoDados para buscar o item
        if (item != null) {
            System.out.println("Item encontrado: " + item);
            return item;
        } else {
            System.out.println("Item não encontrado.");
            return null;
        }
    }

    public Item selecionarItemParaDevolucao() {
        String titulo = receberTitulo();
        Item item = bancoDados.buscarItem(Livro.class, titulo); // Use bancoDados para buscar o item
        if (item != null) {
            System.out.println("Item encontrado: " + item);
            return item;
        } else {
            System.out.println("Item não encontrado.");
            return null;
        }
    }
}
