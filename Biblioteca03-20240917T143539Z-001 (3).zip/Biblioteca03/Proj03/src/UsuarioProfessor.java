public class UsuarioProfessor extends Usuario {

    public UsuarioProfessor(String nome) {
        super(nome,4);
    }

    @Override
    public int getCotaMaxima() {
        return 5; //cota max
    }

    @Override
    public int getPrazoMaximo() {
        return 14; // prazo max
    }

    @Override
    public boolean isProfessor() {
        return true;
    }

    public boolean bloqueiaLivro(Livro livro, int prazo) {
        return livro.bloqueia(this, prazo);
    }

    public boolean desbloqueiaLivro(Livro livro) {
        return livro.desbloqueia(this);
    }

    @Override
    public String toString() {
        return "Prof. " + super.getNome();
    }
}
