import java.util.ArrayList;
import java.util.List;

public class ControleBiblioteca {
    private List<Item> itens;
    private List<Usuario> usuarios;

    public ControleBiblioteca() {
        itens = new ArrayList<>();
        usuarios = new ArrayList<>();
    }

    // Adiciona um item à biblioteca
    public void adicionarItem(Item item) {
        itens.add(item);
    }

    // Adiciona um usuário à biblioteca
    public void adicionarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    // Empresta um item para um usuário
    public boolean emprestarItem(String titulo, Usuario usuario) {
        for (Item item : itens) {
            if (item.getTitulo().equals(titulo)) {
                return item.empresta(usuario);
            }
        }
        return false;
    }

    // Retorna um item emprestado por um usuário
    public boolean retornarItem(String titulo, Usuario usuario) {
        for (Item item : itens) {
            if (item.getTitulo().equals(titulo)) {
                return item.retorna(usuario);
            }
        }
        return false;
    }

    // Exibe o status de um item
    public String exibirStatusItem(String titulo) {
        for (Item item : itens) {
            if (item.getTitulo().equals(titulo)) {
                return item.toString();
            }
        }
        return "Item não encontrado.";
    }

    //lista tudo da biblioteca
    public List<Item> listarItensDisponiveis() {
        List<Item> disponiveis = new ArrayList<>();
        for (Item item : itens) {
            if (item.isDisponivel()) {
                disponiveis.add(item);
            }
        }
        return disponiveis;
    }
    public Livro buscarLivro(String titulo) {
        for (Item item : itens) {
            if (item instanceof Livro && item.getTitulo().equals(titulo)) {
                return (Livro) item;
            }
        }
        return null;
    }
    public boolean emprestarItem(Usuario usuario, Livro livro) {
        return livro.empresta(usuario); 
    }
    
    public boolean retornarItem(Usuario usuario, Livro livro) {
        return livro.retorna(usuario); 
    }
    
    
}
