import java.util.Date;

public class UsuarioAluno extends Usuario {
    private Date dataLimite;

    public UsuarioAluno(String nome, Date dataLimite) {
        super(nome,2);
        this.dataLimite = dataLimite;
    }

    @Override
    public int getCotaMaxima() {
        return isRegular() ? 3 : 2; 
    }

    @Override
    public int getPrazoMaximo() {
        return isRegular() ? 7 : 4; // Define o prazo máximo para alunos
    }

    public void renovaCartao(Date novaData) {
        this.dataLimite = novaData;
    }

    public boolean isRegular() {
        Date hoje = new Date();
        return dataLimite.after(hoje);
    }

    public boolean isARenovar() {
        return !isRegular();
    }

    @Override
    public String toString() {
        return "Aluno " + getNome();
    }
}
