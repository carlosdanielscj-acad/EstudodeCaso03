import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class MapaTematico extends Item {
    private String nivelPrivilegio; 

    public MapaTematico(String titulo, String nivelPrivilegio) {
        super(titulo);
        this.nivelPrivilegio = nivelPrivilegio;
    }

    @Override
    public boolean empresta(Usuario u) {
        return empresta(u, 2); 
    }

    public boolean empresta(Usuario u, int prazo) {
        if (this.isDisponivel() && this.podeEmprestarPara(u)) {
            this.retiradoPor = u;
            this.dtEmprestimo = new Date();
            Calendar cal = new GregorianCalendar();
            cal.setTime(this.dtEmprestimo);
            cal.add(Calendar.DATE, prazo);
            this.dtDevolucao = cal.getTime();
            return true;
        }
        return false;
    }

    @Override
    public boolean retorna(Usuario u) {
        if (this.isEmprestado() && u.equals(this.retiradoPor)) {
            this.retiradoPor = null;
            this.dtEmprestimo = null;
            this.dtDevolucao = null;
            return true;
        }
        return false;
    }

    private boolean podeEmprestarPara(Usuario u) {
        if (nivelPrivilegio.equals("qualquer usuário")) {
            return true;
        } else if (nivelPrivilegio.equals("alunos ou professores")) {
            return u.isUsuarioAluno() || u.isUsuarioProfessor();
        } else if (nivelPrivilegio.equals("somente professores")) {
            return u.isProfessor();
        }
        return false;
    }

    @Override
    public String toString() {
        if (this.isDisponivel()) {
            return this.titulo + " disponível";
        } else if (this.isEmprestado()) {
            return this.titulo + " retirado por " + this.retiradoPor + " até " + dma(this.dtDevolucao);
        } else {
            return this.titulo + " bloqueado";
        }
    }
    //checar data valida
    private String dma(Date dt) {
        if (dt == null) return "Data desconhecida";
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(dt);
        return cal.get(Calendar.DATE) + "/" +
                (cal.get(Calendar.MONTH) + 1) + "/" +
                cal.get(Calendar.YEAR);
    }

    public void setNivelPrivilegio(String nivelPrivilegio) {
        this.nivelPrivilegio = nivelPrivilegio;
    }
}
