import java.util.ArrayList;

public class BancoDados {
    private ArrayList<Item> itens;
    private ArrayList<Usuario> usuarios;

    public BancoDados() {
        itens = new ArrayList<>();
        usuarios = new ArrayList<>();
    }

    // Adiciona um item ao banco de dados
    public void adicionarItem(Item item) {
        if (item != null && !itens.contains(item)) {
            itens.add(item);
        } else {
            System.out.println("Item já está cadastrado ou é nulo.");
        }
    }

    // Remove um item do banco de dados
    public void removerItem(Item item) {
        if (item != null && itens.contains(item)) {
            itens.remove(item);
        } else {
            System.out.println("Item não encontrado ou é nulo.");
        }
    }

    // Adiciona um usuário ao banco de dados
    public void adicionarUsuario(Usuario usuario) {
        if (usuario != null && !usuarios.contains(usuario)) {
            usuarios.add(usuario);
        } else {
            System.out.println("Usuário já está cadastrado ou é nulo.");
        }
    }

    // Remove um usuário do banco de dados
    public void removerUsuario(Usuario usuario) {
        if (usuario != null && usuarios.contains(usuario)) {
            usuarios.remove(usuario);
        } else {
            System.out.println("Usuário não encontrado ou é nulo.");
        }
    }

    // Busca um item pelo tipo e título
    public Item buscarItem(Class<? extends Item> tipoItem, String titulo) {
        if (titulo == null) {
            System.out.println("Título não pode ser nulo.");
            return null;
        }

        for (Item item : itens) {
            if (tipoItem.isInstance(item) && item.getTitulo().equalsIgnoreCase(titulo)) {
                return item;
            }
        }
        return null;
    }

    // Busca um usuário pelo número
    public Usuario buscarUsuario(int numero) {
        for (Usuario usuario : usuarios) {
            if (usuario.getNumero() == numero) {
                return usuario;
            }
        }
        return null;
    }

    // Bloqueia um usuário
    public void bloquearUsuario(Usuario usuario) {
        if (usuario != null && usuarios.contains(usuario)) {
            usuario.bloquear();
            System.out.println("Usuário bloqueado.");
        } else {
            System.out.println("Usuário não encontrado ou é nulo.");
        }
    }

    // Desbloqueia um usuário
    public void desbloquearUsuario(Usuario usuario) {
        if (usuario != null && usuarios.contains(usuario)) {
            usuario.desbloquear();
            System.out.println("Usuário desbloqueado.");
        } else {
            System.out.println("Usuário não encontrado ou é nulo.");
        }
    }

    // Exibe a situação de empréstimos de um usuário
    public void exibirSituacao(Usuario usuario) {
        if (usuario == null) {
            System.out.println("Usuário não pode ser nulo.");
            return;
        }

        System.out.println("Situação do usuário: " + usuario);
        for (Item item : itens) {
            if (item.isEmprestado() && item.getRetiradoPor().equals(usuario)) {
                System.out.println(item);
            }
        }
    }
}
