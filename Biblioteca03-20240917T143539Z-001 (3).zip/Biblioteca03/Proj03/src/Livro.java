import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Livro extends Item {
    private Usuario bloqueadoPor;
    private Date dtBloqueio;
    private Date dtDesbloqueio;

    public Livro(String titulo) {
        super(titulo);
    }

    @Override
    public boolean empresta(Usuario u) {
        return empresta(u, 14);
    }

    public boolean empresta(Usuario u, int prazo) {
        if (this.isDisponivel() && !this.isBloqueado()) {
            this.retiradoPor = u;
            this.dtEmprestimo = new Date();
            GregorianCalendar cal = new GregorianCalendar();
            cal.setTime(this.dtEmprestimo);
            cal.add(Calendar.DATE, prazo);
            this.dtDevolucao = cal.getTime();
            return true;
        }
        return false;
    }
    
    @Override
    public boolean retorna(Usuario u) {
        if (this.isEmprestado() && u.equals(this.retiradoPor)) {
            this.retiradoPor = null;
            this.dtEmprestimo = null;
            this.dtDevolucao = null;
            return true;
        }
        return false;
    }

    public boolean bloqueia(Usuario u, int prazo) {
        if (this.isDisponivel()) {
            this.bloqueadoPor = u;
            this.dtBloqueio = new Date();
            Calendar cal = new GregorianCalendar();
            cal.setTime(this.dtBloqueio);
            cal.add(Calendar.DATE, prazo);
            this.dtDesbloqueio = cal.getTime();
            return true;
        }
        return false;
    }

    public boolean desbloqueia(Usuario u) {
        if (this.isBloqueado() && u.equals(this.bloqueadoPor)) {
            this.bloqueadoPor = null;
            this.dtBloqueio = null;
            this.dtDesbloqueio = null;
            return true;
        }
        return false;
    }

    public boolean isBloqueado() {
        return this.bloqueadoPor != null && this.dtDesbloqueio != null && new Date().before(this.dtDesbloqueio);
    }

    @Override
    public String toString() {
        if (this.isDisponivel()) {
            return this.titulo + " disponível";
        } else if (this.isEmprestado()) {
            return this.titulo + " retirado por " + this.retiradoPor + " até " + dma(this.dtDevolucao);
        } else if (this.isBloqueado()) {
            return this.titulo + " bloqueado por " + this.bloqueadoPor + " até " + dma(this.dtDesbloqueio);
        } else {
            return this.titulo + " indisponível";
        }
    }

    private String dma(Date dt) {
        if (dt == null)
            return "Data desconhecida";
        Calendar cal = new GregorianCalendar();
        cal.setTime(dt);
        return cal.get(Calendar.DATE) + "/" +
                (cal.get(Calendar.MONTH) + 1) + "/" +
                cal.get(Calendar.YEAR);
    }
}
