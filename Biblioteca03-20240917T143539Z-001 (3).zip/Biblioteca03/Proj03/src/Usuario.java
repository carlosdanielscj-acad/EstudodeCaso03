import java.util.ArrayList;

public abstract class Usuario {
    private String nome;
    private ArrayList<Livro> livrosRetirados;
    private int numero;
    private boolean bloqueado; // Atributo para indicar se o usuário está bloqueado

    public Usuario(String nome, int numero) {
        this.nome = nome;
        this.numero = numero;
        this.livrosRetirados = new ArrayList<>();
        this.bloqueado = false; // Inicialmente, o usuário não está bloqueado
    }

    public boolean retiraLivro(Livro livro) {
        if (isAptoARetirar() && !bloqueado) {
            if (livro.empresta(this, getPrazoMaximo())) {
                this.livrosRetirados.add(livro);
                return true;
            }
        }
        return false;
    }

    public boolean devolveLivro(Livro livro) {
        if (livro.retorna(this)) {
            this.livrosRetirados.remove(livro);
            return true;
        }
        return false;
    }

    public abstract int getCotaMaxima();

    public abstract int getPrazoMaximo();

    public boolean isAptoARetirar() {
        return !isADevolver() && !bloqueado;
    }

    public boolean isADevolver() {
        return (this.livrosRetirados.size() >= this.getCotaMaxima() || this.temPrazoVencido());
    }

    private boolean temPrazoVencido() {
        for (Livro livro : this.livrosRetirados) {
            if (livro.isEmAtraso()) {
                return true;
            }
        }
        return false;
    }

    public boolean isProfessor() {
        return false;
    }

    public boolean isUsuarioAluno() {
        return false;
    }

    public boolean isUsuarioProfessor() {
        return false;
    }

    public String getNome() {
        return this.nome;
    }

    public int getNumero() {
        return this.numero;
    }

    public void bloquear() {
        this.bloqueado = true;
    }

    public void desbloquear() {
        this.bloqueado = false;
    }

    @Override
    public String toString() {
        return "Usuário " + nome;
    }

    public String listaCarga() {
        StringBuilder carga = new StringBuilder();
        carga.append(this.toString())
                .append(" Limite: ")
                .append(this.getCotaMaxima())
                .append(" Carga atual: ")
                .append(this.livrosRetirados.size());

        for (Livro livro : this.livrosRetirados) {
            carga.append("\n")
                    .append(livro.toString());
        }
        return carga.toString();
    }
}
