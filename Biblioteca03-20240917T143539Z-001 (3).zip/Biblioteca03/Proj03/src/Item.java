import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public abstract class Item {
    protected String titulo;
    protected Usuario retiradoPor;
    protected Date dtEmprestimo;
    protected Date dtDevolucao;

    public Item(String titulo) {
        this.titulo = titulo;
    }

    public abstract boolean empresta(Usuario u);

    public abstract boolean retorna(Usuario u);

    public boolean isDisponivel() {
        return this.retiradoPor == null;
    }

    public boolean isEmprestado() {
        return this.retiradoPor != null;
    }

    public boolean isEmAtraso() {
        return this.isEmprestado() && this.dtDevolucao != null && new Date().after(this.dtDevolucao);
    }

    public Usuario getRetiradoPor() { 
        return this.retiradoPor;
    }

    public String getTitulo() { 
        return this.titulo;
    }

    @Override
    public String toString() {
        if (this.isDisponivel()) {
            return this.titulo + " disponível";
        } else if (this.isEmprestado()) {
            return this.titulo + " retirado por " + this.retiradoPor + " até " + dma(this.dtDevolucao);
        } else {
            return this.titulo + " bloqueado";
        }
    }

    private String dma(Date dt) {
        if (dt == null)
            return "Data desconhecida";
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(dt);
        return cal.get(Calendar.DATE) + "/" +
                (cal.get(Calendar.MONTH) + 1) + "/" +
                cal.get(Calendar.YEAR);
    }
}
